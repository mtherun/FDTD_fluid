close all;
clear all;
clc;
% type= ["DoubleConcave" "DoubleConvex" "PlanoConcave" "PlanoConvex" "PlanoConcave_Orientation2" "PlanoConvex_Orientation2"];
type= [ "PlanoConcave" "PlanoConcave_Orientation2" ];
fn=1;
for(ii=1:2)
    dh=0.01;
    domains2=imread( type(ii)+".bmp");
    rc= domains2(:,:,1);
    domains = double(rc(end:-1:1, :)');

    domains=double(domains);
    m1=max(domains, [], 'all');
    [nx,ny]=size(domains);



    figure(fn)
    fn=fn+1;
    pcolor(1:nx-1,1:ny,(diff(domains).'~=0)*1.1);shading flat;axis image


    rho1=997;
    c1=1500;
    k1= c1^2*rho1;
    rho2=rho1 *2;
    c2=c1*2;
    k2= c2^2*rho2;
    z1=rho1*c1;
    z2=rho2*c2;
    bitarray1=domains./m1;
    nb1= ~bitarray1;


    bitarray1=1+bitarray1;
    k=[k2 k1];
    rho=[rho2 rho1];
    k=k(bitarray1);
    rho=rho(bitarray1);
    rhox=(rho(1:end-1,:)+rho(2:end,:))/2;
    rhoy=(rho(:,1:end-1)+rho(:,2:end))/2;
    c=[c2 c1];
    c=c(bitarray1);
    z=[z2 z1];
    z=z(bitarray1);
    dt=0.01/(c1+c2)/sqrt(2);
    p=zeros(nx,ny);px=zeros(nx,ny);py=zeros(nx,ny); %sound preassure
    ux=zeros(nx+1,ny); %particle velocity
    uy=zeros(nx,ny+1);

    maxtt=5000;centralfrequency=2000;
    a=centralfrequency/(sqrt(pi)/2)*4;
    t=((1:maxtt)/(1/dt)-4/a);
    w=-(exp(-a^2*(t.^2)/2).*(a^2*(t.^2)-1));

    %__________________________________________________________
    lengthPML=15;
    gammamax=.5;
    gammaux=zeros(nx+1,ny);
    gammaux(1:lengthPML,:)=repmat(gammamax*[((lengthPML:-1:1)/lengthPML).^2]',1,ny);
    gammaux(1+end-lengthPML:end,:)=repmat(gammamax*[((1:1:lengthPML)/lengthPML).^2]',1,ny);
    gammax=zeros(nx,ny);
    gammax=(gammaux(1:end-1,:)+gammaux(2:end,:))/2;
    gammauy=zeros(nx,ny+1);
    gammauy(:,1:lengthPML)=repmat(gammamax*[((lengthPML:-1:1)/lengthPML).^2],nx,1);
    gammauy(:,1+end-lengthPML:end)=repmat(gammamax*[((1:1:lengthPML)/lengthPML).^2],nx,1);
    gammay=zeros(nx,ny);
    gammay=(gammauy(:,1:end-1)+gammauy(:,2:end))/2;
    %__________________________________________________________


    for(tt=1:maxtt)

        %preassure calculation
        px=px.*(1-gammax)-k.*(dt/dh*diff(ux));
        py=py.*(1-gammay)-k.*(dt/dh*diff(uy')');
        %excitacion
        %         px(round(.5/dh),round(.5/dh))=w(tt);
        py(round(nx/5),round(ny/2))=w(tt);
        px(round(nx/5),round(ny/2))=w(tt);
        p=px+py;
        %velocity calculation
        ux(2:nx,:)=ux(2:nx,:).*(1-gammaux(2:nx,:))-dt./rhox/dh.*diff(p);
        uy(:,2:ny)=uy(:,2:ny).*(1-gammauy(:,2:ny))-dt./rhoy/dh.*diff(p')';
        %boundary conditions
        ux(1,:)=-p(1,:)./rhox(1,:)./c(1,:)./z(1,:);
        ux(end,:)=p(end,:)./rhox(end,:)./c(end,:)./z(end,:);
        uy(:,1)=-p(:,1)./rhoy(:,1)./c(:,1)./z(:,1);
        uy(:,end)=p(:,end)./rhoy(:,end)./c(:,end)./z(:,end);

        h(tt)=p(round(end/1.05),round(end/2));
        h2(tt)=p(round(end/1.05),round(end/10));

        if tt/50==round(tt/50);
            figure(fn)

            pcolor((1:nx)*dh,(1:ny)*dh,10*log10(p'.^2/(2e-5).^2));

            set(gca,'Clim',[-30 90]);shading flat,axis equal; colormap jet; colorbar;
            title(['time=' num2str(round((tt)*1000*dt)) ' ms']);drawnow
        end
    end


    fn=fn+1;
    % end
    H=abs(fft2(h));
    H=H(1:round(end/2));
    HE=H.^2;

    H2=abs(fft2(h2));
    H2=H2(1:round(end/2));
    H2E=H2.^2;

    W=abs(fft(w'));
    W=W(1:round(end/2));
    WE=W.^2;

    n=length(h);f=(0:n/2-1)/n*(1/dt);
    figure(fn)
    fn=fn+1;
    plot(f,(H),f,(W),LineWidth=2)
    xlabel("Frequency in Hz",FontSize=20)
    ylabel("Magnitude",FontSize=20)
    set(gca,'FontSize',12)

    axis([0 5000 0 180])
    figure(fn)
    fn=fn+1;
    plot(f,(10*log10((HE))),f,(10*log10(W)),LineWidth=2)
    xlabel("Frequency in Hz",FontSize=20)
    ylabel("Energy Spectral density",FontSize=20)
    set(gca,'FontSize',12)
    axis([0 6000 -40 60])
    figure(fn)
    fn=fn+1;
    plot((1:maxtt),h,(1:maxtt),w/2,LineWidth=2);
    xlabel("time in s",FontSize=20)
    ylabel("Pressure in Pa",FontSize=20)
    set(gca,'FontSize',12)
    legend("Wave after traversing mediums" ,"Source signal")
    fn=fn+1;
end